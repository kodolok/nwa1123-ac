#ifndef SNMPTSMSTATS_H
#define SNMPTSMSTATS_H

/** Initializes the snmpTsmStats module */
void init_snmpTsmStats(void);
void shutdown_snmpTsmStats(void);

#endif /* SNMPTSMSTATS_H */
